from phishvizlib.helloworld import print_hello_world


def hello_world(event, context):
    print_hello_world()